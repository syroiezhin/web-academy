//
//  ViewController.swift
//  Home_work_9_Syroiezhin
//
//  Created by Valerii Syroiezhin on 02.11.2021.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var addButton: UIBarButtonItem!
    @IBOutlet var editButton: UIBarButtonItem!
    @IBOutlet var tableView: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return infoData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellIndentifier", for: indexPath)
        cell.textLabel?.text = infoData[indexPath.row][0]
        cell.detailTextLabel?.text = infoData[indexPath.row][1]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            deleteData(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else { }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func addFunc(_ sender: Any) {
        let controller = UIAlertController(title: "title", message: "message", preferredStyle: .alert)
        
        controller.addTextField { (textField) in
            textField.placeholder = "введіть name"
        }
        controller.addTextField { (textField) in
            textField.placeholder = "введіть nick"
        }
        
        controller.addAction(UIAlertAction(title: "save", style: .default, handler: { (alert) in
            add(name: controller.textFields![0].text!, nick: controller.textFields![1].text!)
            self.tableView.reloadData()
            
        }))
        controller.addAction(UIAlertAction(title: "cancel", style: .default, handler: { (alert) in
            
        }))
        
        present(controller,animated: true, completion: nil)
    }
}

