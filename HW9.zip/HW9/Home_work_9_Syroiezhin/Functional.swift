//
//  Functional.swift
//  Home_work_9_Syroiezhin
//
//  Created by Valerii Syroiezhin on 02.11.2021.
//

import Foundation

var infoData: [[String]] {
    set {
        UserDefaults.standard.set(newValue, forKey: "dataKey")
        UserDefaults.standard.synchronize()
        print("save")
    }
    
    get{
        if let array = UserDefaults.standard.array(forKey: "dataKey") as? [[String]] {
            return array
        } else {
            return [["A","nick:a"],["B","nick:b"],["C","nick:c"],["D","nick:d"],["E","nick:e"],["F","nick:f"],["G","nick:g"],["H","nick:h"],["I","nick:i"],["J","nick:j"],["K","nick:k"],["L","nick:l"],["M","nick:m"],["N","nick:n"],["O","nick:o"],["P","nick:p"],["Q","nick:q"],["R","nick:r"],["S","nick:s"],["T","nick:t"],["U","nick:u"],["V","nick:v"],["W","nick:w"],["X","nick:x"],["Y","nick:y"],["Z","nick:z"]]
        }
    }
}

func add(name: String, nick: String) {
    infoData.append([name,nick])
    save()
}

func deleteData(at index: Int) {
    infoData.remove(at: index)
    save()
}

func save() {
    UserDefaults.standard.set(infoData, forKey: "dataKey")
    UserDefaults.standard.synchronize()
    print("save")
}
