//
//  ViewController.swift
//  Home_work_2_Syroiezhin
//
//  Created by Valerii Syroiezhin on 23.09.2021.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    var myValuesRow:Double = 1
    
    lazy var pickerView: UIPickerView = {
        
        // Generate UIPickerView.
        let picker = UIPickerView()
        
        // Specify the size.
        picker.frame = CGRect(x: 0, y: 25, width: self.view.bounds.width, height: 125.0)
        
        // Set the delegate.
        picker.delegate = self
        
        // Set the dataSource.
        picker.dataSource = self
        
        return picker
    }()
    
    private let values: [String] = ["1","2","3","4","5","6","7","8","9","10",
                                    "11","12","13","14","15","16","17","18","19","20",
                                    "21","22","23","24","25","26","27","28","29","30",
                                    "31","32","33","34","35","36","37","38","39","40",
                                    "41","42","43","44","45","46","47","48","49","50"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.addSubview(pickerView)
    }
    
    func addBox(x: Double, y: Double, w: Double, h: Double, c: Int) {
        let boxView = UIView()
        boxView.frame = CGRect(x: x, y: y, width: w, height: h)
        
        if c == 1 { boxView.backgroundColor = UIColor(red: 0.73, green: 0.10, blue: 0.25, alpha: 1.00) }
        else if c == 2 { boxView.backgroundColor = UIColor(red: 0.00, green: 0.42, blue: 0.29, alpha: 1.00) }
        else if c == 3 { boxView.backgroundColor = UIColor(red: 0.09, green: 0.19, blue: 0.54, alpha: 1.00) }
        else { boxView.backgroundColor = .white }
        
        view.addSubview(boxView)
    }
    
    func libleText(y: Double, t: String) {
        let label = UILabel()
        label.frame = CGRect(x: 10, y: y, width: Double(windowWidth())-20, height: 50)
        label.font = .boldSystemFont(ofSize: 16)
        label.text = t
        label.backgroundColor = .white
        label.textColor = .black
        label.textAlignment = .center
        label.layer.cornerRadius = 8
        label.clipsToBounds = true
        label.numberOfLines = 0
        label.layer.borderColor = UIColor.black.cgColor
        label.layer.borderWidth = 2
        
        view.addSubview(label)
    }
    
    func windowWidth() -> CGFloat {
        return UIScreen.main.bounds.size.width
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // Data source method that returns the number of rows to display in the picker.
    // (Implementation required)
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return values.count
    }
    
    //    // Delegate method that returns the value to be displayed in the picker.
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return values[row]
    }
    
    // A method called when the picker is selected.
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print("row: \(row)")
        self.myValuesRow = Double(values[row]) ?? 1
        print("value: \(values[row])")
        cubes()
    }
    
    func cubes() {
        
        addBox(x: 0, y: 150, w: Double(windowWidth()), h: 10*Double(windowWidth()), c: 0)
        // clean the screen
        
        //    Row Of Cubes:
        
        let index = 5.0 // indent
        let width = (Double(windowWidth()) - index)/myValuesRow - index
        // count the thickness of the cubes
        for i in 0..<Int(myValuesRow) {
            // display all cubes in the desired number in a line
            addBox(x: index+Double(i)*(index+width), y: 150, w: Double(width), h: Double(width), c: 1)
        }
        print("ширина куба: \(width)")
        
        //    Two figures:
        
        let form = sqrt(8*myValuesRow + 1) // discriminant of a quadratic equation n^2 + n + 8*Tn = 0
        print("дискриминант уравнения Tn = n(n+1)/2, которая описывает последовательность целого числа фигур Tn, из которых можно сделать пирамиду/треугольник (например, Tn = 1;3;6;10;15;21;28;36;45;55;66;78;91;105.., где n - порядковый номер последовательности числа), для данного числа фигур \(myValuesRow) получим такой дискриминант \(form)")
        
        //    rectangle:
        
        if (form - form.rounded() == 0) {
            let n = (Int(form)-1)/2
            print("получаем параметр уравнения n (число кубиков по ширине и высоте): \(n)")
            
            for i in 0..<n {
                for m in 0...i {
                    addBox(x: Double(windowWidth())/2 - Double(n)*(width+index)/2 + index/2 + Double(m)*(width+index), y: 175+(Double(i)+1)*(width+index), w: Double(width), h: Double(width), c: 2)
                }
            }
            
            //    pyramid:
            
            for i in 0..<n {
                for m in 0...i {
                    addBox(x: Double(windowWidth())/2 + (Double(m)-Double(i)/2)*(width+index) - width/2, y: 200+(Double(i)+1+Double(n))*(width+index), w: Double(width), h: Double(width), c: 3)
                }
            }
        } else {
            libleText(y: 175+Double(width), t: "число кубиків не достатньо,\nщоб побудувати прямокутник і піраміду".uppercased())
            // Error
        }
        
    }
}
