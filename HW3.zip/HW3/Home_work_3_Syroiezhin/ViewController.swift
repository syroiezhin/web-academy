//
//  ViewController.swift
//  Home_work_3_Syroiezhin
//
//  Created by Valerii Syroiezhin on 22.10.2021.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    //Задача 0
    @IBOutlet weak var textFieldLeft: UITextField!
    @IBOutlet weak var textFieldRight: UITextField!
    @IBOutlet weak var inequalitySign: UILabel!
    
    //Задача 1
    @IBOutlet weak var textFieldLeftRaise: UITextField!
    @IBOutlet weak var textFieldDegree: UITextField!
    @IBOutlet weak var result: UILabel!
    
    //Задача 2
    @IBOutlet weak var textFieldMaximum: UITextField!
    @IBOutlet weak var subsequence: UILabel!
    
    //Задача 3
    @IBOutlet weak var textFieldDividend: UITextField!
    @IBOutlet weak var dividers: UILabel!
    
    //Задача 4
    @IBOutlet weak var perfectNumber: UILabel!
    
    //Block 2
    @IBOutlet weak var BlockTwo: UILabel!
    @IBOutlet weak var textFieldReflect: UITextField!
    @IBOutlet weak var reflected: UILabel!
    
    //змінні
    var null = "0" // загальна константа
    //З№0
    var textLeft = 0
    var textRight = 0
    //З№1
    var textLeftRaise = 0
    var textDegree = 0
    //З№2
    var textMaximum = 0
    var numbers = [Int] (0...0)
    //З№3
    var textDividend = 0
    var results: [Int] = [0]
    //З№4
    var sum = 0
    var printText = ""
    //Block 2
    var month = 0
    var money = 0.0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //З№0
        textFieldLeft.delegate = self
        textFieldRight.delegate = self
        //З№1
        textFieldLeftRaise.delegate = self
        textFieldDegree.delegate = self
        //З№2
        textFieldMaximum.delegate = self
        //З№3
        textFieldDividend.delegate = self
        //Block 2
        textFieldReflect.delegate = self
        
        //З№0
        textFieldLeft.placeholder = null
        textFieldRight.placeholder = null
        //З№1
        textFieldLeftRaise.placeholder = null
        textFieldDegree.placeholder = "2"
        //З№2
        textFieldMaximum.placeholder = null
        //З№3
        textFieldDividend.placeholder = null
        //Block 2
        textFieldReflect.placeholder = null
        
        //З№0
        textFieldLeft.addTarget(self, action: #selector(editingChangedZero(_:)), for: .editingChanged)
        textFieldRight.addTarget(self, action: #selector(editingChangedZero(_:)), for: .editingChanged)
        //З№1
        textFieldLeftRaise.addTarget(self, action: #selector(editingChangedOne(_:)), for: .editingChanged)
        textFieldDegree.addTarget(self, action: #selector(editingChangedOne(_:)), for: .editingChanged)
        //З№2
        textFieldMaximum.addTarget(self, action: #selector(editingChangedTwo(_:)), for: .editingChanged)
        //З№3
        textFieldDividend.addTarget(self, action: #selector(editingChangedThree(_:)), for: .editingChanged)
        //Block 2
        textFieldReflect.addTarget(self, action: #selector(editingChangedReflect(_:)), for: .editingChanged)
        
        repeat { // до Задачі 3
            money = Double(2400 + 700*(Double(month)+1) - 1000*((1-pow(1.03,Double(month)+1))/(1-1.03)))
            month = month + 1
            print("Block 2, Задача 3: \(month) -- \(money)")
        } while (money > 0)
        
        self.BlockTwo.text =
        " Задача 1: $24 під 6% річ.дох. з 1826 по 2021.   Розв'язок: 24 * 1.06^[2021 - 1826] =\n = $\(String(format: "%.1f", 24*pow(1.06,2021-1826))) ≈ $\(String(format: "%.3f", 24*pow(1.06,2021-1826)/1000000)) млн. \n\n" +
        // Формула Суми геометричної прогресії: https://ru.wikipedia.org/wiki/%D0%A1%D1%83%D0%BC%D0%BC%D0%B0_(%D0%BC%D0%B0%D1%82%D0%B5%D0%BC%D0%B0%D1%82%D0%B8%D0%BA%D0%B0)#:~:text=%D0%A1%D1%83%D0%BC%D0%BC%D0%B0%20%D0%B3%D0%B5%D0%BE%D0%BC%D0%B5%D1%82%D1%80%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%BE%D0%B9%20%D0%BF%D1%80%D0%BE%D0%B3%D1%80%D0%B5%D1%81%D1%81%D0%B8%D0%B8
        " Задача 2: витрати 1000*1.03^(m-1) грн/міс, де m - номер міс, починаючи з першого, 700 грн/міс стипендія на протязі 10 міс. Скільки коштів невистачає? [Сума геометричної прогресії] \nРозв'язок: 1000*[(1 -1.03^10))/(1 -1.03)] -700*10 = \(String(format: "%.1f", 1000*((1-pow(1.03,10))/(1-1.03)) - 700*10)) грн. - недостатньо грошей \n\n" +
        
        " Задача 3: скільки студент проживе за власні накопичення, 2400 грн, з урахування стипендії у розмірі 700 грн/міс, якщо витрачає він 1000*1.03^(m-1) грн/міс, де m - номер місяця, починаючи з першого. \nРозв'язок: [2400+700*m] - [1000*(1 -1.03^m)/(1 -1.03)] = { Грошей вистачає на \(month-1) міс; \n \(month)-ого місяця невистачить \(String(format: "%.1f", Double(money))) грн. } \n\n" +
        
        " Задача 4: записати число в зворотньому порядку: "
        // из textFieldReflect в reflected
    }
    
    
    //Задача 0: "Вывести на экран наибольшее из двух чисел" changed textFieldL & textFieldR
    @objc func editingChangedZero(_ textField: UITextField) {
        
        textLeft = Int(textFieldLeft.text ?? "") ?? 0
        textRight = Int(textFieldRight.text ?? "") ?? 0
        
        if textLeft < textRight {
            self.inequalitySign.text = "<"
        } else if textLeft > textRight {
            self.inequalitySign.text = ">"
        } else { // ==
            self.inequalitySign.text = "="
        }
        print("#0 Comparison result: \(textLeft) \(String(inequalitySign.text!)) \(textRight)")
    }
    
    
    //Задача 1: "Вывести на экран квадрат и куб числа"
    @objc func editingChangedOne(_ textField: UITextField) {
        
        textLeftRaise = Int(textFieldLeftRaise.text ?? "") ?? 0
        textDegree = Int(textFieldDegree.text ?? "") ?? 2
        self.result.text = String(Int(pow(Double(textLeftRaise),Double(textDegree))))
        print("#1 Result: \(textLeftRaise) ^ \((textDegree)) = \(String(result.text!))")
    }
    
    
    //Задача 2: "Вывести на экран все числа до заданного и в обратном порядке до 0"
    @objc func editingChangedTwo(_ textField: UITextField) {
        textMaximum = Int(textFieldMaximum.text ?? "") ?? 0
        
        if textMaximum > 0  {
            numbers = [Int] (0...textMaximum-1)
            numbers = numbers + numbers.reversed()
            self.subsequence.text = String(numbers.description.dropFirst().dropLast())
        } else { self.subsequence.text = null }
        
        print("#2 Subsequence: \(String(numbers.description.dropFirst().dropLast()))")
    }
    
    
    //Задача 3: "Подсчитать общее количество делителей числа и вывести их"
    @objc func editingChangedThree(_ textField: UITextField) {
        textDividend = Int(textFieldDividend.text ?? "") ?? 0
        for divider in 0..<textDividend {
            if textDividend % (divider+1) == 0 {
                results[0] = results[0] + 1
                results.append(divider+1)
            }
            self.dividers.text = String("results \(results[0]): \(results[1...results[0]])")
        }
        
        if textFieldDividend.text != "" && textFieldDividend.text != "0" {
            print("#3 Received results number \(textDividend), (divider:\(results[0])): \(results[1...results[0]])")
        } else {
            print("#3 ERROR: Empty field!!!")
            self.dividers.text = "undefined"
        }
        
        
        //Задача 4: "Проверить, является ли заданное число совершенным и найти их (делители)
        sum = results[0...results[0]].reduce(0,+) - results[0] - results[results[0]]
        if sum == textDividend && textDividend != 0 {
            printText = "Результат додавання: \(sum); \n Вітаю, ви знайшли досконале число!"
        } else if textDividend == 0 {
            printText = "Результат додавання: ERROR: Undefined!!! \n Вказане число не досконале число!"
        } else {
            printText = "Результат додавання: \(sum); \n Вказане число не досконале число!"
        }
        print(printText)
        self.perfectNumber.text = printText
        
        results = [0] // видаляємо данні
    }
    
    @objc func editingChangedReflect(_ textField: UITextField) { //Block 2: Задача 4
        self.reflected.text = String(textFieldReflect.text!.reversed())
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let numberOnly = NSCharacterSet.init(charactersIn: "1234567890")
        let stringFromTextField = NSCharacterSet.init(charactersIn: string)
        let limitTextFieldReflect = textFieldReflect.text!.count + string.count - range.length
        
        if limitTextFieldReflect > 2 { //Block 2: Задача 4 (обмежує на введення більше ніж двох чисел)
            print("ERROR: You have already entered a two-digit number !!!")
            return limitTextFieldReflect <= 2
        }
        
        return numberOnly.isSuperset(of: stringFromTextField as CharacterSet)
    }
}
