//
//  ViewController.swift
//  Home_work_7_Syroiezhin
//
//  Created by Valerii Syroiezhin on 31.10.2021.
//

import UIKit

class ViewControllerThree: UIViewController, UITextFieldDelegate {
    
    var firstName = "ім'я"
    var lastName = "прізвище"
    
    @IBOutlet weak var error: UILabel!
    @IBOutlet weak var labelThree: UILabel!
    @IBOutlet weak var textFieldThree: UITextField!
    @IBOutlet weak var buttonThree: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textFieldThree.delegate = self
        textFieldThree.text = firstName + " " + lastName
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destinationVC: ViewController = (segue.destination as? ViewController)!
        destinationVC.fullName = textFieldThree.text!
    }
}

