//
//  ViewController.swift
//  Home_work_7_Syroiezhin
//
//  Created by Valerii Syroiezhin on 31.10.2021.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    var fullName = "повне ім'я"
    var FirstName = "ім'я"
    
    @IBOutlet weak var error: UILabel!
    @IBOutlet weak var labelOne: UILabel!
    @IBOutlet weak var textFieldOne: UITextField!
    @IBOutlet weak var buttonOne: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.textFieldOne.autocapitalizationType = .words
        textFieldOne.delegate = self
        labelOne.textColor = .black
        buttonOne.isEnabled = false
        if fullName != "повне ім'я" {
            labelOne.text = "файне ім'я, " + fullName + ", \nбажаю гарного настрою 👱🏻‍♀️😎👩🏻‍🦱"
            labelOne.textColor = UIColor(red: 242/255.0, green: 243/255.0, blue: 244/255.0, alpha: 1)
//            view.backgroundColor = UIColor(red: 23/255.0, green: 114/255.0, blue: 69/255.0, alpha: 1)
            buttonOne.isEnabled = false
            buttonOne.isUserInteractionEnabled = false
            textFieldOne.isHidden = true
        }
    }
    
    @IBAction func editingChanged(_ sender: Any) {
        if textFieldOne.text?.count == 0 { buttonOne.isEnabled = false }
        else { buttonOne.isEnabled = true }
        
        if textFieldOne.text!.count > 11 {
            error.text = "ERROR: maximum number \nof characters entered !!!"
            error.textColor = .red
        } else { error.text = "" }
        
        if Int(textFieldOne.text?.count ?? 0) > 1 {
            textFieldOne.text = textFieldOne.text!.prefix(1).uppercased() + textFieldOne.text!.suffix(Int(textFieldOne.text?.count ?? 1)-1).lowercased()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destinationVC: ViewControllerTwo = (segue.destination as? ViewControllerTwo)!
        destinationVC.firstName = textFieldOne.text!
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let numberOnly = CharacterSet.letters
        let stringFromTextField = NSCharacterSet.init(charactersIn: string)
        let limitTextFieldName = textField.text!.count + string.count - range.length
        
        if limitTextFieldName > 12 {
            print("ERROR: You have entered a name that is too large !!!")
            return limitTextFieldName <= 12
        }
        return numberOnly.isSuperset(of: stringFromTextField as CharacterSet)
    }
}
