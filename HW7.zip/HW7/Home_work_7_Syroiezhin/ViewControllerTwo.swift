//
//  ViewController.swift
//  Home_work_7_Syroiezhin
//
//  Created by Valerii Syroiezhin on 31.10.2021.
//

import UIKit

class ViewControllerTwo: UIViewController, UITextFieldDelegate {

    var firstName = "ім'я"
    var lastName = "прізвище"
    
    @IBOutlet weak var error: UILabel!
    @IBOutlet weak var labelTwo: UILabel!
    @IBOutlet weak var buttonTwo: UIButton!
    @IBOutlet weak var textFieldTwo: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.textFieldTwo.autocapitalizationType = .words
        textFieldTwo.delegate = self
        buttonTwo.isEnabled = false
    }
    
    @IBAction func editingChanged(_ sender: Any) {
        if textFieldTwo.text?.count == 0 { buttonTwo.isEnabled = false }
        else { buttonTwo.isEnabled = true }
        
        if textFieldTwo.text!.count > 11 {
            error.text = "ERROR: maximum number \nof characters entered !!!"
            error.textColor = .red
        } else { error.text = "" }
        
        if Int(textFieldTwo.text?.count ?? 0) > 1 {
            textFieldTwo.text = textFieldTwo.text!.prefix(1).uppercased() + textFieldTwo.text!.suffix(Int(textFieldTwo.text?.count ?? 1)-1).lowercased()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destinationVC: ViewControllerThree = (segue.destination as? ViewControllerThree)!
        destinationVC.firstName = firstName
        destinationVC.lastName = textFieldTwo.text!
    }
}

