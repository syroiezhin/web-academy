//
//  ViewController.swift
//  Home_work_2.2_Syroiezhin
//
//  Created by Valerii Syroiezhin on 16.10.2021.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var myTextField: UITextField!
    
    var numberOfLayers = "0"
    var shapeWidth = 0.0
    var indent = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        myTextField.delegate = self
        myTextField.placeholder = numberOfLayers
        myTextField.addTarget(self, action: #selector(editingChanged(_:)), for: .editingChanged)
    }
    
    @objc func editingChanged(_ textField: UITextField) {
        //changed textField
        numberOfLayers = String(myTextField.text!)
        addBox(x: windowWidth()/4, y: 75, w: windowWidth()/2, h: windowWidth()/2, c: "blue", r: "square")
        addBox(x: windowWidth()/4, y: 100 + windowWidth()/2, w: windowWidth()/2, h: windowWidth()/2, c: "blue", r: "circle")
        addBox(x: 10, y: 125 + windowWidth(), w: windowWidth() - 20, h: 50, c: "white", r: "square")
        
        if numberOfLayers != "" && Int(numberOfLayers)! > 100 {
            numberOfLayers = "100" // більше не влізає
            libleText(y: 125 + windowWidth(), t: "Що занадто, то не здраво".uppercased()) // error
        }
        
        // draw a red frame
        if numberOfLayers != "" && numberOfLayers > "0" {
            for p in 0..<Int(numberOfLayers)! {
                indent = windowWidth()/(2*(2*Double(numberOfLayers)!+1))
                print("получили \(Double(numberOfLayers)!)")
                shapeWidth = windowWidth()/2 - 2*indent*CGFloat(p+1)
                //4*CGFloat(p+1)
                addBox(x: windowWidth()/4 + indent*CGFloat(p+1), y: 75 + indent*CGFloat(p+1), w: shapeWidth, h: shapeWidth, c: "red", r: "square")
                addBox(x: windowWidth()/4 + indent*CGFloat(p+1), y: 100 + windowWidth()/2 + indent*CGFloat(p+1), w: shapeWidth, h: shapeWidth, c: "red", r: "circle")
            }
        }
        
    }
    
    func addBox(x: Double, y: Double, w: Double, h: Double, c: String, r: String) {
        let box = UIView()
        box.frame = CGRect(x: x, y: y, width: w, height: h)
        
        
        box.backgroundColor = .blue
        box.layer.borderWidth = 1.0
        
        switch c {
        case "red":
            box.layer.borderColor = UIColor.red.cgColor
        case "white":
            box.backgroundColor = .white
            box.layer.borderColor = UIColor.white.cgColor
        default:
            box.layer.borderColor = UIColor.blue.cgColor
        }
        
        if r == "circle" {
            box.layer.cornerRadius = box.frame.size.width / 2
            box.clipsToBounds = true
        }
        
        view.addSubview(box)
    }
    
    func libleText(y: Double, t: String) {
        let label = UILabel()
        label.frame = CGRect(x: 10, y: y, width: Double(windowWidth())-20, height: 50)
        label.font = .boldSystemFont(ofSize: 16)
        label.text = t
        label.backgroundColor = .white
        label.textColor = .black
        label.textAlignment = .center
        label.layer.cornerRadius = 8
        label.clipsToBounds = true
        label.numberOfLines = 0
        label.layer.borderColor = UIColor.black.cgColor
        label.layer.borderWidth = 2
        
        view.addSubview(label)
    }
    
    func windowWidth() -> CGFloat {
        return UIScreen.main.bounds.size.width
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let numberOnly = NSCharacterSet.init(charactersIn: "0123456789")
        let stringFromTextField = NSCharacterSet.init(charactersIn: string)
        let strValid = numberOnly.isSuperset(of: stringFromTextField as CharacterSet)
        return strValid
    }
}


//#if canImport(SwiftUI) && DEBUG
//import SwiftUI
//
//struct SwiftLeeViewRepresentable: UIViewRepresentable {
//    func makeUIView(context: Context) -> UIView {
//        return UIStoryboard(name: "Main", bundle: Bundle.main).instantiateInitialViewController()!.view
//    }
//
//    func updateUIView(_ view: UIView, context: Context) {
//
//    }
//}
//
//@available(iOS 13.0, *)
//struct SwiftLeeViewController_Preview: PreviewProvider {
//    static var previews: some View {
//        SwiftLeeViewRepresentable()
//    }
//}
//#endif
