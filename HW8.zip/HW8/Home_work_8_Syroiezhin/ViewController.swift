//
//  ViewController.swift
//  Home_work_8_Syroiezhin
//
//  Created by Valerii Syroiezhin on 31.10.2021.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var closeViewExit: UIButton!
    @IBOutlet weak var viewExit: UIView!
    @IBOutlet weak var buttonViewExit: UIButton!
    @IBOutlet var textFieldLogin: UITextField!
    @IBOutlet var textFieldPassword: UITextField!
    @IBOutlet var buttonSeePassword: UIButton!
    @IBOutlet var exitButton: UIButton!
    @IBOutlet var error: UILabel!
    var see = false
    var grade = [0,0,0,0,0]
    
    @IBOutlet weak var buttonTumblerGame: UIButton!
    @IBOutlet weak var numberOfClicks: UILabel!
    var bool = false
    var enumerator = [0,0,0]
    let viewGame = UIView()
    var timer = Timer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        loginAndPassword()
        viewMyGame()
    }
    
    func loginAndPassword() {
        textFieldLogin.delegate = self
        textFieldPassword.delegate = self
        textFieldPassword.isSecureTextEntry = true /************/
        viewExit.isHidden = true
        closeViewExit.isHidden = true
        exitButton.isEnabled = false
    }
    
    @IBAction func tapExitButton(_ sender: UIButton) {
        viewExit.isHidden = false
        buttonViewExit.isHidden = true
        closeViewExit.isHidden = false
        numberOfClicks.isHidden = true
        buttonTumblerGame.isHidden = true
        if viewGame.isHidden == false {
            viewGame.isHidden = true
            bool = false
            buttonTumblerGame.setImage(UIImage(systemName: "gamecontroller.fill"), for: .normal)
        }
    }
    
    @IBAction func tapCloseExitButton(_ sender: UIButton) {
        numberOfClicks.isHidden = false
        viewExit.isHidden = true
        buttonViewExit.isHidden = false
        closeViewExit.isHidden = true
        buttonTumblerGame.isHidden = false
    }
    
    @IBAction func seePassword(_ sender: UIButton) {
        see.toggle()
        if see == true {
            textFieldPassword.isSecureTextEntry = false
            buttonSeePassword.setImage(UIImage(systemName: "eye.circle"), for: .normal)
        } else {
            textFieldPassword.isSecureTextEntry = true
            buttonSeePassword.setImage(UIImage(systemName: "eye.slash.circle"), for: .normal)
        }
    }
    
    // GAME
    
    func viewMyGame() {
        viewGame.frame = CGRect(x: Int(windowWidth()/2 - 50), y: Int(windowHeight()/2 - 50), width: 100, height: 100)
        self.view.addSubview(viewGame)
        viewGame.backgroundColor = .white
        viewGame.isHidden = true
        numberOfClicks.text = "0"
        viewGame.isUserInteractionEnabled = true
        viewGame.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:))))
    }
    
    @IBAction func tumblerGame(_ sender: UIButton) {
        bool.toggle()
        if bool == true {
            viewGame.isHidden = false
            buttonTumblerGame.setImage(UIImage(systemName: "gamecontroller"), for: .normal)
        } else {
            viewGame.isHidden = true
            buttonTumblerGame.setImage(UIImage(systemName: "gamecontroller.fill"), for: .normal)
        }
    }
    
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
        timer.invalidate()
        enumerator[0] += 1
        random()
    }
    
    @objc func random() {
        timer.invalidate()
        enumerator[1] += 1
        enumerator[2] = 2*enumerator[0] - enumerator[1]
        numberOfClicks.text = "\(enumerator[2])"
        print("\(enumerator[2])")
        
        viewGame.frame = CGRect(x: Int.random(in: 0...Int(windowWidth() - 100)), y: Int.random(in: 0...Int(windowHeight() - 100)), width: 100, height: 100)
        
        if enumerator[2] <= -10 {
            print("game over")
            viewGame.isHidden = true
            numberOfClicks.text = "game over"
        } else if enumerator[2] >= 10 {
            print("congratulations, you won")
            viewGame.isHidden = true
            numberOfClicks.text = "congratulations, you won"
        } else {
            print("keep it up, you can do it")
            timer = Timer.scheduledTimer(timeInterval: 1.5, target: self, selector: #selector(random), userInfo: nil, repeats: true)
        }
    }
    
    // Додатково
    
    func windowWidth() -> CGFloat {
        return UIScreen.main.bounds.size.width
    }
    
    func windowHeight() -> CGFloat {
        return UIScreen.main.bounds.size.height
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let numberOnly = CharacterSet(charactersIn:" !%$()”,.:;?^_+{}[]|<>`/\'•¢").inverted
        let stringFromTextField = NSCharacterSet.init(charactersIn: string)
        let limitTextFieldName = textField.text!.count + string.count - range.length
        
        if textFieldLogin.text == "" && textFieldPassword.text == "" {
            exitButton.isEnabled = false
            textFieldPassword.isUserInteractionEnabled = false
        } else {
            exitButton.isEnabled = true
            textFieldPassword.isUserInteractionEnabled = true
        }
        
        if limitTextFieldName > 12 {
            error.text = "no more characters can be entered"
            print("ERROR: no more characters can be entered !!!")
            return limitTextFieldName < 12
        } else if limitTextFieldName < 8 {
            error.text = "too few characters"
            print("ERROR: too few characters !!!")
            return limitTextFieldName >= 0
        } else {
            for item in String(textFieldPassword.text!).unicodeScalars {
                
                if item.value >= 48 && item.value <= 57 { // отримуємо та порівнюємо числове значення символу
                    //a) якщо пароль містить число
                    grade[0] = 1
                } else if (item.value >= 65 && item.value <= 90) {
                    //b) символ верхнього регістру
                    grade[1] = 1
                } else if (item.value >= 97 && item.value <= 122) {
                    //c) символ нижнього регістру
                    grade[2] = 1
                } else {
                    //d) спец символи _ + - = ~ # * & № @
                    grade[3] = 1
                }
                
                if textFieldPassword.text!.count >= 8 {
                    grade[4] = 1
                } //d) наявність 8 символів
            }
            error.text = "reliability assessment \((Array(grade).reduce(0, +))*20)%"
            print("reliability assessment  \((Array(grade).reduce(0, +))*20)%")
        }
        return numberOnly.isSuperset(of: stringFromTextField as CharacterSet)
    }
}

