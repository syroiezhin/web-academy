//
//  ViewController.swift
//  Home_work_4_Syroiezhin
//
//  Created by Valerii Syroiezhin on 24.10.2021.
//

import UIKit
import Foundation

class ViewController: UIViewController, UITextFieldDelegate { //, UITextFieldDelegate {
    //Task1
    @IBOutlet weak var textFieldName: UITextField!
    @IBOutlet weak var numberOfLetters: UILabel!
    //Task2
    @IBOutlet weak var textFieldLastName: UITextField!
    @IBOutlet weak var ending: UILabel!
    //Task3
    @IBOutlet weak var fullNameMerged: UILabel!
    @IBOutlet weak var fullNameSeparately: UILabel!
    //Task4
    @IBOutlet weak var textFieldMirror: UITextField!
    @IBOutlet weak var mirror: UILabel!
    //Task5
    @IBOutlet weak var textFieldCommas: UITextField!
    //Task6
    @IBOutlet weak var textFieldPassword: UITextField!
    @IBOutlet weak var password: UILabel!
    //Task7
    @IBOutlet weak var textFieldMassif: UITextField!
    @IBOutlet weak var massif: UILabel!
    //Task8
    @IBOutlet weak var passInAnotherAlphabet: UITextField!
    @IBOutlet weak var received: UILabel!
    //Task9
    @IBOutlet weak var textFieldSearchSuggestion: UITextField!
    @IBOutlet weak var textFieldSearch: UITextField!
    @IBOutlet weak var resultSearch: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        assignment3Task1()
        assignment3Task2()
        assignment3Task3()
        assignment3Task4()
        assignment3Task5()
        assignment3Task6()
        assignment3Task7()
        assignment3Task8()
        assignment3Task9()
        //        assignment3Task10() // антимам влаштував у assignment3Task9() !!!
    }
    
    func assignment3Task1() {
        textFieldName.delegate = self
        textFieldName.placeholder = "введіть ім'я"
        textFieldName.text = "Valery"
        self.textFieldName.autocapitalizationType = .words
        textFieldName.addTarget(self, action: #selector(editingChanged1(_:)), for: .editingChanged)
        editingChanged1(textFieldName)
    }
    
    @objc func editingChanged1(_ textField: UITextField) {
        self.numberOfLetters.text = "\(Array(textFieldName.text!).count) літер"
        print("\nassignment3Task1: \(String(textFieldName.text!)), \(Array(textFieldName.text!).count) літер")
        assignment3Task3()
    }
    
    func assignment3Task2() {
        textFieldLastName.delegate = self
        textFieldLastName.placeholder = "прізвище"
        textFieldLastName.text = "Syroiezhin"
        self.textFieldLastName.autocapitalizationType = .words // не блокує набір великих літер після набору першої літери, а лише змінює регістр
        textFieldLastName.addTarget(self, action: #selector(editingChanged2(_:)), for: .editingChanged)
        editingChanged2(textFieldLastName)
    }
    
    @objc func editingChanged2(_ textField: UITextField) {
        
        // Змінюємо великі літери набрані власноруч на маленькі, після великої першої
        if Int(textFieldLastName.text?.count ?? 0) > 1 {
            textFieldLastName.text = textFieldLastName.text!.prefix(1).uppercased() + textFieldLastName.text!.suffix(Int(textFieldLastName.text?.count ?? 1)-1).lowercased()
        } // для наглядності дивись попеденє поле з ім'ям, там можно ввести великі літери через caps lock
        
        if textFieldLastName.text!.lowercased().suffix(3) == "ich" || textFieldLastName.text!.lowercased().suffix(2) == "ич" || textFieldLastName.text!.lowercased().suffix(2) == "на" || textFieldLastName.text!.lowercased().suffix(2) == "na" {
            self.ending.text = "\(textFieldLastName.text!.suffix(2))"
            print("\nassignment3Task2: останні літери \(textFieldLastName.text!.suffix(2))")
        } else {
            self.ending.text = "не ич/на"
            print("\nassignment3Task2: останні літери не ич/на")
        }
        assignment3Task3()
    }
    
    func assignment3Task3() {
        let LastName = String(textFieldName.text!+textFieldLastName.text!)
        fullNameMerged.text = LastName
        var letterNumber = 0
        
        for item in LastName.unicodeScalars {
            
            //A...Z + А...Я + Ё + Є + І + Ї + Ґ
            if (item.value >= 65 && item.value <= 90) || (item.value >= 1040 && item.value <= 1071) || item.value == 1025 || item.value == 1028 || item.value == 1030 || item.value == 1031 || item.value == 1168 { // отримуємо та порівнюємо числове значення символу
                print("")
                letterNumber=1 // коли знайде верхній регістр
            } else {
                letterNumber+=1 // тоді він підрахує скільки літер у прізвищі
            }
            print("assignment3Task3: \(letterNumber). \(item) = \(item.value);")
        }
        fullNameSeparately.text = "\(LastName.prefix(LastName.count-letterNumber))   \(LastName.suffix(letterNumber))"
        
        print("assignment3Task3: було \(LastName), а стало \(LastName.prefix(LastName.count-letterNumber)) \(LastName.suffix(letterNumber))")
    }
    
    func assignment3Task4() {
        textFieldMirror.delegate = self
        textFieldMirror.placeholder = "введіть слово"
        textFieldMirror.text = "name"
        textFieldMirror.addTarget(self, action: #selector(editingChanged4(_:)), for: .editingChanged)
        editingChanged4(textFieldMirror)
    }
    
    @objc func editingChanged4(_ textField: UITextField) {
        var myMirror = Array(textFieldMirror.text!)
        print("\nassignment3Task4: \(myMirror) -- \(myMirror.count/2)")
        
        for index in 0..<myMirror.count/2 {
            print("assignment3Task4: \(index+1) -- \(myMirror[index]) -- \(myMirror[Int(myMirror.count)-1 - index]) -- \(String(myMirror))")
            
            (myMirror[index], myMirror[Int(myMirror.count)-1 - index]) = (myMirror[Int(myMirror.count)-1 - index], myMirror[index])
        }
        
        print("assignment3Task4: Result: \(String(myMirror))")
        self.mirror.text = String(myMirror)
    }
    
    func assignment3Task5() {
        textFieldCommas.delegate = self
        textFieldCommas.keyboardType = .numberPad
        textFieldCommas.placeholder = "введіть число"
        textFieldCommas.text = "0000000000000000000000000000000000000000000000000000000000000000000000009876543210"
        textFieldCommas.addTarget(self, action: #selector(editingChanged5(_:)), for: .editingChanged)
        editingChanged5(textFieldCommas)
    }
    
    @objc func editingChanged5(_ textField: UITextField) {
        if Int(textFieldCommas.text!) == 0 || String(textFieldCommas.text!) == "" {
            textFieldCommas.text = "0"
            print("editingChanged5: порожній textField")
        } else if textFieldCommas.text!.dropLast((textFieldCommas.text?.count ?? 1)-1) == "0" {
            repeat {
                textFieldCommas.text = String(textFieldCommas.text!.dropFirst())
            } while (textFieldCommas.text!.dropLast((textFieldCommas.text?.count ?? 1)-1) == "0")
        }
        
        textFieldCommas.text = textFieldCommas.text!.replacingOccurrences(of: "'", with: "")
        
        let number = (textFieldCommas.text?.count ?? 0) % 3
        let commas = (Int(textFieldCommas.text?.count ?? 0) - number)/3
        let prefixNumber = String(Array(textFieldCommas.text!).prefix(number))
        var resultCommas = ""
        
        if commas > 0 {
            for cms in 0...commas-1 {
                resultCommas = resultCommas + "'" + textFieldCommas.text!.dropFirst(number+3*cms).dropLast(3*(commas-1-cms))
            }
        }
        
        if prefixNumber == "" {
            resultCommas = String(resultCommas.dropFirst())
        }
        
        textFieldCommas.text = prefixNumber + resultCommas
        print("\neditingChanged5: у поле записане число: \(String(textFieldCommas.text!)), символів: \(textFieldCommas.text?.count ?? 0)")
    }
    
    func assignment3Task6() {
        textFieldPassword.placeholder = "введіть пароль: Pas+w0rd"
        textFieldPassword.text = ""
        textFieldPassword.addTarget(self, action: #selector(editingChanged6(_:)), for: .editingChanged)
        editingChanged6(textFieldPassword)
    }
    
    @objc func editingChanged6(_ textField: UITextField) {
        var grade = [0,0,0,0,0]
        for item in String(textFieldPassword.text!).unicodeScalars {
            
            if item.value >= 48 && item.value <= 57 { // отримуємо та порівнюємо числове значення символу
                //a) если пароль содержит числа
                grade[0] = 1
            } else if (item.value >= 65 && item.value <= 90) {
                //b) символы верхнего регистра
                grade[1] = 1
            } else if (item.value >= 97 && item.value <= 122) {
                //c) символы нижнего регистра
                grade[2] = 1
            } else {
                //d) спец символы
                grade[3] = 1
            }
            
            if textFieldPassword.text!.count >= 8 { grade[4] = 1 }
        }
        password.text = "\((Array(grade).reduce(0, +))*20)%"
        print("\neditingChanged6: \(String(password.text!)) - оцінка якості вашого паролю")
    }
    
    func assignment3Task7() {
        textFieldMassif.delegate = self
        textFieldMassif.placeholder = "введіть масив"
        textFieldMassif.text = "59996847030876"
        textFieldMassif.addTarget(self, action: #selector(editingChanged7(_:)), for: .editingChanged)
        editingChanged7(textFieldMassif)
    }
    
    @objc func editingChanged7(_ textField: UITextField) {
        print("\nassignment3Task7: в масиві")
        var grade = [Int]()
        let string = String(textFieldMassif.text!)
        for i in 0...9 {
            if string.contains("\(i)") { grade.append(i) }
        }
        
        if grade.isEmpty {
            print("немає чисел")
            self.massif.text = "масив пустий"
        } else {
            print("є елементи: \n було \(Array(textFieldMassif.text!)) \n стало \(grade)")
            self.massif.text = grade.description
        }
    }
    
    func assignment3Task8() {
        passInAnotherAlphabet.delegate = self
        passInAnotherAlphabet.placeholder = "введіть речення"
        passInAnotherAlphabet.text = "(Многим ”«\"нулям\"»” кажется, что они именно бублик ;:- а не дырка от него!.)?%$"
        passInAnotherAlphabet.addTarget(self, action: #selector(editingChanged8(_:)), for: .editingChanged)
        editingChanged8(passInAnotherAlphabet)
    }
    
    @objc func editingChanged8(_ textField: UITextField) {
        let translit: [String: String]  = [" ":" ",".":".",",":",","!":"!","?":"?","(":"(",")":")","\"":"\"","”":"”","«":"«","»":"»",":":":",
                                           ";":";","-":"-","$":"$","%":"%","А":"A","Б":"B","В":"V","Г":"G","Д":"D","Е":"E","Ё":"JE","Ж":"ZH","З":"Z",
                                           "И":"I","Й":"Y","К":"K","Л":"L","М":"M","Н":"N","О":"O","П":"P","Р":"R","С":"S","Т":"T","У":"U","Ф":"F",
                                           "Х":"KH","Ц":"C","Ч":"CH","Ш":"SH","Щ":"JSH","Ъ":"HH","Ы":"IH","Ь":"JH","Э":"EH","Ю":"JU","Я":"JA"]
        
        let received = passInAnotherAlphabet.text!.uppercased().compactMap { translit[String($0)] }
        self.received.text = received.joined(separator: "")
        print("\nassignment3Task8: \(received.joined(separator: ""))")
    }
    
    func assignment3Task9() {
        textFieldSearchSuggestion.delegate = self
        textFieldSearch.delegate = self
        textFieldSearchSuggestion.placeholder = "введіть речення"
        //        textFieldSearchSuggestion.text = "Многим нулям кажется, что они именно бублик, а не дырка от него. Вы так не считаете? Як мені здається, такі люди дурні"
        textFieldSearchSuggestion.text = "Дурак доказывает что он не дурак, а умный и так это знает. Только в коллективе ничтожество обретает силу. Нищие не завидуют миллионерам — они завидуют другим нищим, которым подают больше."
        textFieldSearch.placeholder = "пошук"
        textFieldSearch.text = "ко"
        textFieldSearchSuggestion.addTarget(self, action: #selector(editingChanged9(_:)), for: .editingChanged)
        textFieldSearch.addTarget(self, action: #selector(editingChanged9(_:)), for: .editingChanged)
        editingChanged9(textFieldSearch)
        editingChanged9(textFieldSearchSuggestion)
    }
    
    @objc func editingChanged9(_ textField: UITextField) {
        var dictionary = [String]()
        let antimat = ["дур", "ничтожество", "нищ"]
        var star = ""
        textFieldSearchSuggestion.text = textFieldSearchSuggestion.text
        var SearchSuggestion = textFieldSearchSuggestion.text!
        SearchSuggestion = SearchSuggestion.replacingOccurrences(of: ",", with: " ,")
        SearchSuggestion = SearchSuggestion.replacingOccurrences(of: ".", with: " .")
        SearchSuggestion = SearchSuggestion.replacingOccurrences(of: "?", with: " ?")
        SearchSuggestion = SearchSuggestion.replacingOccurrences(of: "!", with: " !")
        
        var Search = SearchSuggestion.components(separatedBy: " ") // розділяємо слова та символи через наявність пробілів між ними
        print("assignment3Task9: розбили речення на слова та символи у масиві: \(Search[0...Search.count-1])")
        
        for i in 0...Search.count-1 {
            if Search[i].lowercased().contains(textFieldSearch.text!.lowercased()) { // перевіряє чи є у textFieldSearchSuggestion - textFieldSearch
                dictionary.append(Search[i])
            }
            
            for j in 0...antimat.count-1 {                                                // editingChanged10 ANTIMAT
                if Search[i].lowercased().contains(antimat[j].lowercased()) {             // editingChanged10 ANTIMAT
                    for _ in 0..<Search[i].count { star = star + "*" }                    // editingChanged10 ANTIMAT
                    Search[i] = star                                                      // editingChanged10 ANTIMAT
                    textFieldSearchSuggestion.text = Search.joined(separator: " ")        // editingChanged10 ANTIMAT
                    star = ""                                                             // editingChanged10 ANTIMAT
                }                                                                         // editingChanged10 ANTIMAT
            }                                                                             // editingChanged10 ANTIMAT
        }
        
        if textFieldSearch.text == "" { // якщо пошук textFieldSearch пустий
            self.resultSearch.text = "нічого-не-знайдено"
        } else { // якщо пошук textFieldSearch не пустий
            self.resultSearch.text = "[" + dictionary.joined(separator: ", ") + "]"
        }
        print("assignment3Task9: отримали: \(dictionary)")
        
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var numberOnly = CharacterSet()
        
        if textField == textFieldCommas || textField == textFieldMassif {
            numberOnly = CharacterSet.decimalDigits // тільки числа
        } else if textField == passInAnotherAlphabet || textField == textFieldSearchSuggestion || textField == textFieldSearch{
            numberOnly = CharacterSet(charactersIn:"@#^&_+{}[]|<>~`/=\'•¢abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ").inverted
            // можно вводить ! % $ ( ) ” , . : ; - ? *
        } else {
            numberOnly = CharacterSet.letters // тільки букви
        }
        
        let stringFromTextField = NSCharacterSet.init(charactersIn: string)
        let limitTextFieldName = textFieldName.text!.count + string.count - range.length
        
        if limitTextFieldName > 12 { //Block 2: Задача 4 (обмежує на введення більше ніж двох чисел)
            print("ERROR: You have entered a name that is too large !!!")
            return limitTextFieldName <= 12
        }
        return numberOnly.isSuperset(of: stringFromTextField as CharacterSet)
    }
}
