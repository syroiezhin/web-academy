//
//  ViewController.swift
//  Home_work_5_Syroiezhin
//
//  Created by Valerii Syroiezhin on 27.10.2021.
//

import UIKit

class ViewController: UIViewController {
    
    var resources = [100,100,100,           0,20,30,   25,15,10,  20,10,20,  30,30,0]
    //               resourcesMachine       cappuccino, americano,  latte,    espresso
    
    @IBOutlet weak var result: UILabel!
    
    @IBAction func waterButton(_ sender: Any) {
        resources[0...2] = [100,resources[1],resources[2]]
        label(sender: 0)
    }
    @IBAction func grainButton(_ sender: Any) {
        resources[0...2] = [resources[0],100,resources[2]]
        label(sender: 0)
    }
    @IBAction func milkButton(_ sender: Any) {
        resources[0...2] = [resources[0],resources[1],100]
        label(sender: 0)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func label(sender: Int) {

        if resources[0]-10 >= 0 && resources[1]-20 >= 0 && resources[2]-30 >= 0 { result.text = "🄲" }
        else { result.text = "" }
        if resources[0]-20 >= 0 && resources[1]-30 >= 0 && resources[2]-10 >= 0 { result.text = "\(result.text ?? "") 🄰" }
        if resources[0]-30 >= 0 && resources[1]-10 >= 0 && resources[2]-20 >= 0 { result.text = "\(result.text ?? "") 🄻" }
        if resources[0]-30 >= 0 && resources[1]-30 >= 0 { result.text = "\(result.text ?? "") 🄴" }
        if result.text == "" { result.text = "В: +\(resources[0])%, З: +\(resources[1])%, М: +\(resources[2])%" }
        
        if sender > 0 {
            if resources[0]-resources[3*sender] < 0 {
                result.text = result.text! + ", \nбракує води"
                print("\(sender): ERROR: додайте води")
            }
            if resources[1]-resources[1+3*sender] < 0 {
                result.text = result.text! + ", \nбракує зерна"
                print("\(sender): ERROR: додайте зерно")
            }
            if resources[2]-resources[2+3*sender] < 0 {
                result.text = result.text! + ", \nбракує молока"
                print("\(sender): ERROR: додайте молоко")
            }
        }
        
        print("Залишилось:        В: +\(resources[0])%, З: +\(resources[1])%, М: +\(resources[2])%")
    }
    
    @IBAction func coffeeMachine(_ sender: UISegmentedControl) {
        if resources[0]-resources[3*sender.selectedSegmentIndex] >= 0 && resources[1]-resources[1+3*sender.selectedSegmentIndex] >= 0 && resources[2]-resources[2+3*sender.selectedSegmentIndex] >= 0 {
            resources[0...2] = [resources[0]-resources[0+3*sender.selectedSegmentIndex],resources[1]-resources[1+3*sender.selectedSegmentIndex],resources[2]-resources[2+3*sender.selectedSegmentIndex]]
            print("приємного настрою! В: -\(resources[0+3*sender.selectedSegmentIndex])%, З: -\(resources[1+3*sender.selectedSegmentIndex])%, М: -\(resources[2+3*sender.selectedSegmentIndex])%")
        }
        label(sender: sender.selectedSegmentIndex)
        sleep(1)
        sender.selectedSegmentIndex = 0
    }
}

